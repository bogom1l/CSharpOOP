﻿namespace NavalVessels.IO.Contracts
{
    interface IReader
    {
        string ReadLine();
    }
}
